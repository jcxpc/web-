package datas.domain;

import java.util.Date;
import java.util.List;

public class Account {

	private String userAccount;// �û��˺�
	private String userPassword;// �û�����

	private String accountName; // �û�����
	private String accountSex; // �û��Ա�
	private String userIdNumber;// �û�����֤
	private String userPhone;// �û��绰
	private Date creationTime;// ����ʱ��
	private List<AccountRecord> accountRecordList;

	public Account() {

	}

	public Account(String userAccount, String userPassword, String accountName, String accountSex, String userIdNumber,
			String userPhone, Date creationTime, List<AccountRecord> accountRecordList) {
		super();
		this.userAccount = userAccount;
		this.userPassword = userPassword;
		this.accountName = accountName;
		this.accountSex = accountSex;
		this.userIdNumber = userIdNumber;
		this.userPhone = userPhone;
		this.creationTime = creationTime;
		this.accountRecordList = accountRecordList;
	}

	public List<AccountRecord> getAccountRecordList() {
		return accountRecordList;
	}

	public void setAccountRecordList(List<AccountRecord> accountRecordList) {
		this.accountRecordList = accountRecordList;
	}

	public String getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountSex() {
		return accountSex;
	}

	public void setAccountSex(String accountSex) {
		this.accountSex = accountSex;
	}

	public String getUserIdNumber() {
		return userIdNumber;
	}

	public void setUserIdNumber(String userIdNumber) {
		this.userIdNumber = userIdNumber;
	}

	public String getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	@Override
	public String toString() {
		return "Account [userAccount=" + userAccount + ", userPassword=" + userPassword + ", accountName=" + accountName
				+ ", accountSex=" + accountSex + ", userIdNumber=" + userIdNumber + ", userPhone=" + userPhone
				+ ", creationTime=" + creationTime + ", accountRecordList=" + accountRecordList + "]";
	}
}
