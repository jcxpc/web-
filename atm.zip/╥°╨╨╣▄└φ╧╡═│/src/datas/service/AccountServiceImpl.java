package datas.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import datas.dao.AccountDao;
import datas.domain.Account;
import datas.domain.AccountRecord;

@Service("accountService")
public class AccountServiceImpl implements AccountService {

	private Logger logger = Logger.getLogger(AccountServiceImpl.class);
	float money;
	float smoney;

	@Autowired
	private AccountDao accountDao;

	// �û���¼
	@Override
	public Account accountLoginService(String userAccount, String userPassword) {
		Account account = accountDao.selectUserAccount(userAccount, userPassword);
		System.out.println("��¼ʱ��AccountServiceImpl��ѯ---------->" + account);
		return account;
	}

	// �û�ע��
	@Override
	public boolean insertUserAccount(Account account) {
		int resultRow = accountDao.insertUserAccount(account);
		logger.info("������У�" + resultRow);
		return resultRow > 0;
	}

	// ��ѯ�˻����
	@Override
	public float selectUserAccountBalanceService(String userAccount) {
		AccountRecord accountRecord = accountDao.selectUserAccountBalanceDao(userAccount);
		if (accountRecord == null) {
			return 0;
		}
		money = accountRecord.getAccountBalance();
		logger.info("��ѯ�����˻����----->" + money);
		return money;
	}

	// �û����
	@Override
	public boolean userAccountSave_Service(String userAccount, Float transactionMoney, Float accountBalance) {

		logger.info("���֮ǰ��ѯ�����˻����----->" + money);
		accountBalance = money + transactionMoney;
		logger.info("������Ժ��Ǯ��" + accountBalance);
		int c = accountDao.userAccountSave_Dao(userAccount, transactionMoney, accountBalance);
		if (c == 1) {
			return true;
		}
		return false;
	}

	// �û�ȡ��
	@Override
	public boolean userAccountDraw_Service(String userAccount, Float transactionMoney, Float accountBalance) {

		logger.info("ȡ��֮ǰ��ѯ�����˻����----->" + money);
		accountBalance = money - transactionMoney;
		logger.info("ȡ�����Ժ�ʣ��Ǯ��" + accountBalance);
		int c = accountDao.userAccountDraw_Dao(userAccount, transactionMoney, accountBalance);
		if (c == 1) {
			return true;
		}
		return false;
	}

	// �û�ת��
	@Override
	public boolean userAccountTransfer_Service(String userAccount, String receivableAccount, Float transactionMoney,
			Float accountBalance) {

		logger.info("ת��֮ǰ��ѯ�����˻����----->" + money);
		accountBalance = money - transactionMoney;
		logger.info("ת�����Ժ�ʣ��Ǯ��" + accountBalance);
		int c = accountDao.userAccountTransfer_Dao(userAccount, receivableAccount, transactionMoney, accountBalance);
		if (c == 1) {
			return true;
		}
		return false;
	}

	// ��ѯ�տ��˺Ŵ治����
	@Override
	public boolean selectReceivablesAccount_Service(String receivableAccount) {
		int c = accountDao.selectReceivablesAccount_Dao(receivableAccount);
		logger.info("ת��ʱ���˺�״̬��" + c);
		if (c > 0) {
			return true;
		}

		return false;
	}

	// �տ��˻�������ѯ
	@Override
	public float selectTransferAccountBalanceService(String receivableAccount) {

		AccountRecord accountRecord = accountDao.selectTransferAccountBalanceDao(receivableAccount);
		if (accountRecord == null) {
			return 0;
		}
		smoney = accountRecord.getAccountBalance();
		logger.info("�տ��˻���ѯ�������----->" + smoney);
		return smoney;
	}

	// �û��տ�
	@Override
	public boolean userAccountReceivables_Service(String receivableAccount, String sourceAccount,
			Float transactionMoney, Float accountBalance) {

		logger.info("�տ�֮ǰ��ѯ�����˻����----->" + smoney);
		accountBalance = smoney + transactionMoney;
		logger.info("�տ����Ժ��Ǯ��" + accountBalance);
		int c = accountDao.userAccountReceivables_Dao(receivableAccount, sourceAccount, transactionMoney,
				accountBalance);
		if (c == 1) {
			return true;
		}
		return false;
	}

	// ��ѯ����֤�ź��ֻ�����
	@Override
	public Account select_UserIdNumber_UserPhone_Service(String userAccount) {

		Account account = accountDao.select_UserIdNumber_UserPhone_Dao(userAccount);
		logger.info("����֤���ǣ�" + account.getUserIdNumber());
		logger.info("�ֻ������ǣ�" + account.getUserPhone());
		logger.info("account------>" + account);
		return account;
	}

	// �޸��û�����
	@Override
	public int updateAccountPassword_Service(String userAccount, String userPassword) {

		return accountDao.updateAccountPassword_Dao(userAccount, userPassword);
	}

	// ɾ���û�
	@Override
	public void deleteUserAccount_Service(String userAccount) {
		accountDao.deleteUserAccount_Dao(userAccount);
		accountDao.deleteUserAccountRecord_Dao(userAccount);
	}

}