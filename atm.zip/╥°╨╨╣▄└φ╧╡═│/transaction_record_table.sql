SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for transaction_record_table
-- ----------------------------
DROP TABLE IF EXISTS `transaction_record_table`;
CREATE TABLE `transaction_record_table` (
  `transaction_id` int(255) NOT NULL AUTO_INCREMENT,
  `transaction_type` varchar(255) NOT NULL,
  `user_account` int(255) NOT NULL,
  `receivable_account` varchar(255) NOT NULL,
  `source_account` varchar(255) NOT NULL,
  `transaction_money` varchar(255) NOT NULL,
  `account_balance` varchar(255) NOT NULL,
  `transaction_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`transaction_id`),
  KEY `A_T` (`user_account`),
  CONSTRAINT `A_T` FOREIGN KEY (`user_account`) REFERENCES `account_record_table` (`user_account`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
