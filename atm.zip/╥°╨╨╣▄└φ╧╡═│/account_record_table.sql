SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for account_record_table
-- ----------------------------
DROP TABLE IF EXISTS `account_record_table`;
CREATE TABLE `account_record_table` (
  `user_account` int(10) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_sex` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_ID_number` varchar(255) NOT NULL,
  `user_phone` varchar(255) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_account`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
