package tools;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class JdbcUtil {
    static Properties prop =null;
    static{
        try{
            //��ȡ�����ļ�jdbc.properties
            prop = new Properties();
            String pathname="jdbc.properties";
            prop.load(new FileInputStream(pathname));
        }catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    //1.˽�л����캯����
    // ��ֹ���ֱ��new����
    private JdbcUtil(){}
    //2.�ṩgetConnection��
    // ����������ṩ��ȡ��������
    public static Connection getConnection(){
        try {
            //1.ע������
            Class.forName(
                    prop.getProperty("driverClass"));
            //2.��ȡ���ݿ�����
            Connection conn = DriverManager.getConnection(
                    prop.getProperty("jdbcUrl"),
                    prop.getProperty("user"),
                    prop.getProperty("password"));
            return conn;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;

    }

    // 3.�ṩclose�����������ر���Դ
    public static void close(Connection conn,Statement st,ResultSet rs){

        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }finally{
                //��֤��Դһ���ᱻ�ͷ�
                conn=null;
            }
        }

        if(st!=null){
            try {
                st.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }finally{
                //��֤��Դһ���ᱻ�ͷ�
                st=null;
            }
        }

        if(rs!=null){
            try {
                rs.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }finally{
                //��֤��Դһ���ᱻ�ͷ�
                rs=null;
            }
        }
    }
}
